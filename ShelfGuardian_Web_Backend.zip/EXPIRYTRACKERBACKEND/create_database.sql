-- SQL script to create the database
-- Run this in psql or pgAdmin

CREATE DATABASE expiry_tracker;

-- Optional: Connect to the database and verify
\c expiry_tracker

-- The tables will be created automatically when you run the FastAPI app

